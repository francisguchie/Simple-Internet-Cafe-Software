#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<dos.h>
#include<stdlib.h>
#include<windows.h>
#include<unistd.h>

//DAVID RYAN JOSHUA V
//ORIGINAL NI YA TOOOOO
//HISA KA? SUNDA HAHAHAHA
//PROGRAM KO NI YAAAAAAAAAAAA
//NUGAY KWAN PAKYU KA HA HAHAHAHA
//MODIFICATION NOT ALLOWED

main()
{
    //MAIN MENU
    int choice;
    int gotostart=0;

    beginning:
    Sleep(2000);
    system("COLOR 6");
    printf("===================================\n");
    printf("Welcome to the Billing System!\n");
    printf("===================================\n");
    printf("Press 1 - Add Customer\n");
    printf("Press 2 - Add Billing\n");
    printf("Press 0 - Exit\n");
    printf("===================================\n");
    printf("Type option here ---> ");
    scanf("%d",&choice);

    system("cls");

    if(choice == 1)
    {
        //ADD CUSTOMER
        char fn[20], mi[3], ln[20], addr[50], bd[20];
        time_t t;
        int opt;
        time(&t);
        FILE *ofp;

        Sleep(2000);
        system("COLOR 2");

        ofp = fopen("1.txt","w");

        printf("=========================================\n");
        printf("Add Customer Screen\n");
        printf("Current Time: %s",ctime(&t));
        printf("=========================================\n");
        Sleep(2000);
        printf("\n");
        fgets(mi, 3, stdin);
        printf("Enter First Name: ");
        fgets(fn, 20, stdin);
        printf("Enter Last Name: ");
        fgets(ln, 20, stdin);
        printf("Enter Address: ");
        fgets(addr, 50, stdin);
        printf("Enter birthdate [mm/dd/yyyy]: ");
        fgets(bd, 20, stdin);
        printf("=========================================\n");

        /* loading ka-che-che-an */
        system("cls");
        printf("Saving data entered in Database, please wait.");
        Sleep(1000);
        system("cls");
        printf("Saving data entered in Database, please wait. .");
        Sleep(1000);
        system("cls");
        printf("Saving data entered in Database, please wait. . .");
        Sleep(1000);

        //overview
        Sleep(1000);
        system("COLOR 7");
        system("cls");
        printf("=========================================\n");
        printf("Entry succesfully saved!\n");
        printf("Entry saved at: %s",ctime(&t));
        printf("=========================================\n");
        printf("Press any key to view entry summary.\n");
        getch();
        printf("=========================================\n");
        printf("First Name: %s\n", fn);
        fprintf(ofp, "First name: %s\n", fn);
        printf("Last Name: %s\n", ln);
        fprintf(ofp, "Last name: %s\n", ln);
        printf("Address: %s\n", addr);
        fprintf(ofp, "Address: %s\n", addr);
        printf("Birthdate: %s\n", bd);
        fprintf(ofp, "Birthdate: %s\n", bd);
        fclose(ofp);
        printf("=========================================\n");
        Sleep(10000);

        options:
        printf("Press 1 to return to main menu\n");
        printf("Press 0 to exit program\n");
        printf("Enter choice here --> ");
        scanf("%d",&opt);

        if(opt == 1)
        {
            system("cls");
            goto beginning;
        }

        else if(opt == 0)
        {
            exit(0);
        }

        else
        {
            printf("Option error. Try Again \n");
            goto options;
        }
    }

    else if(choice==2)
    {
        printf("test2");
    }

    else if(choice==0)
    {
        system("COLOR 2");
        int con;
        printf("Are you sure you want to exit? 1 if yes --> ");
        scanf("%d",&con);

        if(con==1)
        {
            exit(0);
        }

        else
        {
            system("cls");
            goto beginning;
        }
    }
    else
    {
        printf("Invalid option");
        goto beginning;
    }
    while (choice != 5);
}
